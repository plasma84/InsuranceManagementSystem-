package com.example.demo.enums;

public enum ProposalStatus {
	PROPOSAL_SUBMITTED,
    QUOTE_GENERATED,
    ACTIVE,
    EXPIRED

}
